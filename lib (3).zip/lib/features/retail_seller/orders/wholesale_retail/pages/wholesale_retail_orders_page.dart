import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:locally/common/extensions/content_extensions.dart';
import 'package:locally/common/providers/orders/order_filter_provider.dart';
import 'package:locally/common/widgets/order/order_search_bar.dart';
import 'package:locally/common/widgets/order/order_status_filter_bar.dart';
import 'package:locally/features/retail_seller/orders/wholesale_retail/widgets/retail_sales_order_card.dart';
import 'package:locally/features/retail_seller/orders/wholesale_retail/providers/order_providers.dart';

class RetailOrdersPage extends ConsumerWidget {
  const RetailOrdersPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ordersAsync = ref.watch(retailerSalesOrdersProvider);
    final query = ref.watch(orderSearchQueryProvider);
    final selectedStatus = ref.watch(selectedOrderStatusProvider);

    return Scaffold(
      backgroundColor: context.colors.surface,
      appBar: AppBar(
        title: Text(
          'Incoming Orders',
          style: context.text.titleLarge?.copyWith(fontWeight: FontWeight.bold),
        ),
        backgroundColor: context.colors.surface,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
      ),
      body: Column(
        children: [
          // Keep your custom widgets
          const OrderSearchBar(),
          const OrderStatusFilterBar(),
          const SizedBox(height: 8),

          Expanded(
            child: ordersAsync.when(
              data: (orders) {
                // --- Your Filtering Logic Preserved ---
                final filtered = orders.where((o) {
                  final matchesQuery = o
                      .id // Assuming model uses 'id' or 'orderId'
                      .toLowerCase()
                      .contains(query.toLowerCase());
                  final matchesStatus =
                      selectedStatus == null ||
                      o.status.name.toLowerCase() ==
                          selectedStatus.toLowerCase();
                  return matchesQuery && matchesStatus;
                }).toList();

                if (filtered.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.inbox_outlined,
                          size: 64,
                          color: context.colors.outline,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          "No orders found",
                          style: context.text.titleMedium,
                        ),
                      ],
                    ),
                  );
                }

                return ListView.separated(
                  padding: const EdgeInsets.all(16).copyWith(bottom: 100),
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 16),
                  itemBuilder: (context, index) {
                    final order = filtered[index];
                    return RetailerSalesOrderCard(
                      order: order,
                      onUpdateStatus: (newStatus) {
                        ref.read(updateConsumerOrderStatusProvider)(
                          orderId: order.id,
                          newStatus: newStatus,
                        );
                      },
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, _) => Center(child: Text('Error: $error')),
            ),
          ),
        ],
      ),
    );
  }
}
