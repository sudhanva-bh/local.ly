// Change the following to match the style of the above format, withoit changing any of the logic

// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:locally/common/extensions/content_extensions.dart';
// import 'package:locally/common/providers/orders/order_filter_provider.dart';
// import 'package:locally/common/providers/orders/order_providers.dart';
// import 'package:locally/common/widgets/order/order_search_bar.dart';
// import 'package:locally/common/widgets/order/order_status_filter_bar.dart';
// // ✅ 1. Import the provider for the update action
// import 'package:locally/common/providers/orders/order_actions_provider.dart';
// import 'package:locally/features/retail_seller/orders/wholesale_retail/widgets/retailer_order_card.dart';

// class RetailOrdersPage extends ConsumerWidget {
//   const RetailOrdersPage({super.key});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final ordersAsync = ref.watch(currentRetailOrdersProvider);
//     final query = ref.watch(orderSearchQueryProvider);
//     final selectedStatus = ref.watch(selectedOrderStatusProvider);

//     return Scaffold(
//       backgroundColor: context.colors.surfaceContainerHighest,
//       appBar: AppBar(
//         title: const Text('My Orders'),
//       ),
//       body: Column(
//         children: [
//           const OrderSearchBar(),
//           const OrderStatusFilterBar(),
//           const SizedBox(height: 8),
//           Expanded(
//             child: ordersAsync.when(
//               data: (orders) {
//                 final filtered = orders.where((o) {
//                   final matchesQuery = o.orderId
//                       .toLowerCase()
//                       .contains(query.toLowerCase());
//                   final matchesStatus = selectedStatus == null ||
//                       o.status.toLowerCase() == selectedStatus.toLowerCase();
//                   return matchesQuery && matchesStatus;
//                 }).toList();

//                 if (filtered.isEmpty) {
//                   return const Center(child: Text('No orders found.'));
//                 }

//                 return ListView.builder(
//                   itemCount: filtered.length,
//                   itemBuilder: (context, index) {
//                     final order = filtered[index];
//                     // ✅ 2. Pass the onUpdateStatus callback to the RetailOrderCard
//                     return RetailOrderCard(
//                       order: order,
//                       onUpdateStatus: (newStatus) {
//                         ref.read(updateOrderStatusProvider)(
//                           orderId: order.orderId,
//                           newStatus: newStatus,
//                         );
//                       },
//                     );
//                   },
//                 );
//               },
//               loading: () => const Center(child: CircularProgressIndicator()),
//               error: (error, _) => Center(child: Text('Error: $error')),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// // lib/common/providers/orders/order_providers.dart

// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:locally/common/models/orders/consumer_order_model.dart';
// import 'package:locally/common/providers/auth_providers.dart';

// // Provider to fetch orders RECEIVED by the retailer (Sales)
// final retailerSalesOrdersProvider = FutureProvider.autoDispose<List<OrderModel>>((ref) async {
//   final user = ref.watch(supabaseClientProvider).auth.currentUser;
//   if (user == null) return [];

//   final supabase = ref.watch(supabaseClientProvider);

//   // Fetch orders where I am the SELLER
//   final data = await supabase
//       .from('orders')
//       .select('*, order_items(*, retail_products(product_name, image_urls))') // Deep fetch
//       .eq('seller_id', user.id) 
//       .order('created_at', ascending: false);

//   final List<dynamic> dataList = data as List<dynamic>;
//   return dataList.map((e) => OrderModel.fromMap(e)).toList();
// });

// // Provider to update order status (For Sales)
// final updateConsumerOrderStatusProvider = Provider((ref) {
//   return ({required String orderId, required String newStatus}) async {
//     final supabase = ref.read(supabaseClientProvider);
//     await supabase.from('orders').update({'status': newStatus}).eq('id', orderId);
//     // Invalidate to refresh the UI
//     ref.invalidate(retailerSalesOrdersProvider);
//   };
// });

// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:intl/intl.dart';
// import 'package:locally/common/extensions/content_extensions.dart';
// import 'package:locally/common/models/orders/consumer_order_model.dart';
// import 'package:locally/features/retail_seller/orders/wholesale_retail/providers/order_providers.dart';
// // import 'package:locally/features/retail_seller/orders/providers/order_providers.dart';

// class RetailerSalesOrderDetailPage extends ConsumerWidget {
//   final OrderModel order;

//   const RetailerSalesOrderDetailPage({super.key, required this.order});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final currencyFormat = NumberFormat.simpleCurrency(locale: 'en_IN');
//     final dateFormat = DateFormat('dd MMM yyyy, hh:mm a');

//     return Scaffold(
//       backgroundColor: context.colors.surface, // Adapts to dark/light mode
//       appBar: AppBar(
//         title: const Text("Order Details"),
//         centerTitle: true,
//         elevation: 0,
//         scrolledUnderElevation: 0,
//         backgroundColor: context.colors.surface,
//         surfaceTintColor: Colors.transparent,
//       ),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.all(16),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             // 1. HEADER CARD
//             _buildHeaderCard(context, dateFormat),
//             const SizedBox(height: 24),

//             // 2. ITEMS
//             Text(
//               "Items",
//               style: context.text.titleMedium?.copyWith(
//                 fontWeight: FontWeight.bold,
//                 color: context.colors.onSurface,
//               ),
//             ),
//             const SizedBox(height: 12),
//             _buildItemsList(context, currencyFormat),
//             const SizedBox(height: 24),

//             // 3. FINANCIAL SUMMARY
//             _buildFinancialCard(context, currencyFormat),
//             const SizedBox(height: 24),

//             // 4. SHIPPING
//             _buildShippingCard(context),

//             const SizedBox(height: 80),
//           ],
//         ),
//       ),
//       bottomSheet: _buildBottomAction(context, ref),
//     );
//   }

//   // ---------------------------------------------------------------------------
//   // UI SECTIONS
//   // ---------------------------------------------------------------------------

//   Widget _buildHeaderCard(BuildContext context, DateFormat dateFormat) {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: context
//             .colors
//             .surfaceContainerLow, // Slightly distinct from background
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: context.colors.outlineVariant),
//       ),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   "Order #${order.id.substring(0, 8).toUpperCase()}",
//                   style: context.text.titleMedium?.copyWith(
//                     fontWeight: FontWeight.bold,
//                     color: context.colors.onSurface,
//                   ),
//                 ),
//                 const SizedBox(height: 4),
//                 Text(
//                   dateFormat.format(order.createdAt),
//                   style: context.text.bodySmall?.copyWith(
//                     color: context.colors.onSurfaceVariant,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           _buildStatusBadge(context, order.status),
//         ],
//       ),
//     );
//   }

//   Widget _buildItemsList(BuildContext context, NumberFormat currencyFormat) {
//     final items = order.items ?? [];

//     if (items.isEmpty) {
//       return Center(
//         child: Text(
//           "No items in this order.",
//           style: TextStyle(color: context.colors.onSurfaceVariant),
//         ),
//       );
//     }

//     return ListView.separated(
//       physics: const NeverScrollableScrollPhysics(),
//       shrinkWrap: true,
//       itemCount: items.length,
//       separatorBuilder: (_, __) => const SizedBox(height: 12),
//       itemBuilder: (context, index) {
//         final item = items[index];
//         return Container(
//           padding: const EdgeInsets.all(12),
//           decoration: BoxDecoration(
//             color: context.colors.surfaceContainerLow,
//             borderRadius: BorderRadius.circular(12),
//             border: Border.all(color: context.colors.outlineVariant),
//           ),
//           child: Row(
//             children: [
//               // Placeholder Icon
//               Container(
//                 width: 48,
//                 height: 48,
//                 decoration: BoxDecoration(
//                   color: context.colors.secondaryContainer,
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: Icon(
//                   Icons.shopping_bag_outlined,
//                   color: context.colors.onSecondaryContainer,
//                   size: 24,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       item.productName ?? "Unknown Product",
//                       style: context.text.bodyLarge?.copyWith(
//                         fontWeight: FontWeight.w600,
//                         color: context.colors.onSurface,
//                       ),
//                       maxLines: 2,
//                       overflow: TextOverflow.ellipsis,
//                     ),
//                     const SizedBox(height: 4),
//                     Text(
//                       "${item.quantity} x ${currencyFormat.format(item.priceAtPurchase)}",
//                       style: context.text.bodySmall?.copyWith(
//                         color: context.colors.onSurfaceVariant,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               Text(
//                 currencyFormat.format(item.quantity * item.priceAtPurchase),
//                 style: context.text.bodyMedium?.copyWith(
//                   fontWeight: FontWeight.bold,
//                   color: context.colors.onSurface,
//                 ),
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }

//   Widget _buildFinancialCard(
//     BuildContext context,
//     NumberFormat currencyFormat,
//   ) {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: context.colors.surfaceContainerLow,
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: context.colors.outlineVariant),
//       ),
//       child: Column(
//         children: [
//           _buildSummaryRow(
//             context,
//             "Subtotal",
//             currencyFormat.format(order.totalAmount),
//           ),
//           Padding(
//             padding: const EdgeInsets.symmetric(vertical: 12.0),
//             child: Divider(color: context.colors.outlineVariant),
//           ),
//           _buildSummaryRow(
//             context,
//             "Total Amount",
//             currencyFormat.format(order.totalAmount),
//             isBold: true,
//             fontSize: 18,
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildSummaryRow(
//     BuildContext context,
//     String label,
//     String value, {
//     bool isBold = false,
//     double fontSize = 14,
//   }) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Text(
//           label,
//           style: TextStyle(
//             fontSize: fontSize,
//             color: isBold
//                 ? context.colors.onSurface
//                 : context.colors.onSurfaceVariant,
//           ),
//         ),
//         Text(
//           value,
//           style: TextStyle(
//             fontSize: fontSize,
//             fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
//             color: context.colors.onSurface,
//           ),
//         ),
//       ],
//     );
//   }

//   Widget _buildShippingCard(BuildContext context) {
//     return Container(
//       width: double.infinity,
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: context.colors.surfaceContainerLow,
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: context.colors.outlineVariant),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Icon(
//                 Icons.local_shipping_outlined,
//                 size: 20,
//                 color: context.colors.primary,
//               ),
//               const SizedBox(width: 8),
//               Text(
//                 "Delivery Address",
//                 style: context.text.titleSmall?.copyWith(
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 8),
//           Text(
//             order.deliveryAddress,
//             style: context.text.bodyMedium?.copyWith(
//               color: context.colors.onSurfaceVariant,
//               height: 1.4,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget? _buildBottomAction(BuildContext context, WidgetRef ref) {
//     if (order.status == OrderStatus.delivered ||
//         order.status == OrderStatus.cancelled) {
//       return null;
//     }

//     final actionText = _getNextActionText(order.status);
//     final isDestructive = order.status == OrderStatus.cancelled;

//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: context.colors.surfaceContainer,
//         boxShadow: [
//           BoxShadow(
//             blurRadius: 10,
//             color: context.colors.shadow.withOpacity(0.1),
//             offset: const Offset(0, -4),
//           ),
//         ],
//       ),
//       child: SafeArea(
//         child: FilledButton(
//           onPressed: () => _advanceStatus(context, ref),
//           style: FilledButton.styleFrom(
//             backgroundColor: isDestructive
//                 ? context.colors.error
//                 : context.colors.primary,
//             foregroundColor: isDestructive
//                 ? context.colors.onError
//                 : context.colors.onPrimary,
//             minimumSize: const Size(double.infinity, 50),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(12),
//             ),
//           ),
//           child: Text(
//             actionText,
//             style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//           ),
//         ),
//       ),
//     );
//   }

//   // ---------------------------------------------------------------------------
//   // HELPERS & BADGES
//   // ---------------------------------------------------------------------------

//   Widget _buildStatusBadge(BuildContext context, OrderStatus status) {
//     Color containerColor;
//     Color onContainerColor;
//     String text = status.name.toUpperCase();

//     // Mapping Status to Material 3 Semantics
//     switch (status) {
//       case OrderStatus.pending:
//         // Use Secondary (often neutral/calm) or Tertiary (often warmer)
//         containerColor = context.colors.secondaryContainer;
//         onContainerColor = context.colors.onSecondaryContainer;
//         break;
//       case OrderStatus.accepted:
//         // Use Primary Container
//         containerColor = context.colors.primaryContainer;
//         onContainerColor = context.colors.onPrimaryContainer;
//         break;
//       case OrderStatus.shipped:
//         // Use Tertiary Container (Distinct from Accepted)
//         containerColor = context.colors.tertiaryContainer;
//         onContainerColor = context.colors.onTertiaryContainer;
//         break;
//       case OrderStatus.delivered:
//         // Use Primary (Strong confirmation)
//         containerColor = context.colors.primary;
//         onContainerColor = context.colors.onPrimary;
//         break;
//       case OrderStatus.cancelled:
//         // Use Error Container
//         containerColor = context.colors.errorContainer;
//         onContainerColor = context.colors.onErrorContainer;
//         break;
//     }

//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//       decoration: BoxDecoration(
//         color: containerColor,
//         borderRadius: BorderRadius.circular(20),
//       ),
//       child: Text(
//         text,
//         style: context.text.labelSmall?.copyWith(
//           color: onContainerColor,
//           fontWeight: FontWeight.bold,
//         ),
//       ),
//     );
//   }

//   String _getNextActionText(OrderStatus status) {
//     switch (status) {
//       case OrderStatus.pending:
//         return "Accept Order";
//       case OrderStatus.accepted:
//         return "Mark as Shipped";
//       case OrderStatus.shipped:
//         return "Mark as Delivered";
//       default:
//         return "Close";
//     }
//   }

//   void _advanceStatus(BuildContext context, WidgetRef ref) {
//     String nextStatus;
//     switch (order.status) {
//       case OrderStatus.pending:
//         nextStatus = 'accepted';
//         break;
//       case OrderStatus.accepted:
//         nextStatus = 'shipped';
//         break;
//       case OrderStatus.shipped:
//         nextStatus = 'delivered';
//         break;
//       default:
//         return;
//     }

//     print("${order.id} $nextStatus");

//     ref.read(updateConsumerOrderStatusProvider)(
//       orderId: order.id,
//       newStatus: nextStatus,
//     );

//     Navigator.pop(context);
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:intl/intl.dart';
// import 'package:locally/common/models/orders/consumer_order_model.dart';
// import 'package:locally/features/retail_seller/orders/wholesale_retail/widgets/retail_sales_details_page.dart';

// class RetailerSalesOrderCard extends ConsumerWidget {
//   final OrderModel order;

//   const RetailerSalesOrderCard({super.key, required this.order});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final textTheme = Theme.of(context).textTheme;
//     final currency = NumberFormat.simpleCurrency(locale: 'en_IN');

//     // Logic to find a display image from the first item in the order
//     // String? firstImageUrl;
//     // Assuming OrderModel -> items -> OrderItemModel
//     // You might need to adjust based on how you nested the product data in the fetch
//     // The provider used: .select('*, order_items(*, retail_products(product_name, image_urls))')
//     if (order.items != null && order.items!.isNotEmpty) {
//       // In Supabase response, this data might be in a map if not fully deserialized,
//       // but assuming OrderItemModel handles it or we access strictly:
//       // For this display, we might just use the Generic Icon to save complexity
//       // unless OrderItemModel has an imageUrl field.
//     }

//     return Card(
//       margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
//       child: ListTile(
//         isThreeLine: true,
//         // 1. Leading: Visual distinction for "Sale" vs "Purchase"
//         leading: Container(
//           width: 48,
//           height: 48,
//           decoration: BoxDecoration(
//             color:
//                 Colors.orange.shade100, // Different color to distinguish Sales
//             borderRadius: BorderRadius.circular(8),
//           ),
//           child: Icon(Icons.shopping_bag, color: Colors.orange.shade800),
//         ),

//         // 2. Title: Customer Name (or ID if name unavailable)
//         title: Text(
//           "Order #${order.id.substring(0, 8).toUpperCase()}",
//           style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
//         ),

//         // 3. Subtitle: Items count and Date
//         subtitle: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               "${order.items?.length ?? 0} items • ${currency.format(order.totalAmount)}",
//             ),
//             Text(DateFormat.yMd().add_jm().format(order.createdAt)),
//           ],
//         ),

//         // 4. Trailing: Status Chip
//         trailing: SizedBox(
//           width: 110, // Slightly wider for status text
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               StatusChip(status: order.status),
//             ],
//           ),
//         ),

//         onTap: () {
//           // Navigate to Detail Page
//           Navigator.of(context).push(
//             MaterialPageRoute(
//               builder: (context) => RetailerSalesOrderDetailPage(order: order),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

// class StatusChip extends StatelessWidget {
//   final OrderStatus status;
//   const StatusChip({required this.status});

//   @override
//   Widget build(BuildContext context) {
//     Color color;
//     switch (status) {
//       case OrderStatus.pending:
//         color = Colors.orange;
//         break;
//       case OrderStatus.accepted:
//         color = Colors.blue;
//         break;
//       case OrderStatus.shipped:
//         color = Colors.purple;
//         break;
//       case OrderStatus.delivered:
//         color = Colors.green;
//         break;
//       case OrderStatus.cancelled:
//         color = Colors.red;
//         break;
//     }

//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//       decoration: BoxDecoration(
//         color: color.withOpacity(0.1),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: color.withOpacity(0.5)),
//       ),
//       child: Text(
//         status.name.toUpperCase(),
//         style: TextStyle(
//           color: color,
//           fontSize: 10,
//           fontWeight: FontWeight.bold,
//         ),
//         textAlign: TextAlign.center,
//       ),
//     );
//   }
// }import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:intl/intl.dart';
// import 'package:locally/common/models/orders/consumer_order_model.dart';
// import 'package:locally/features/retail_seller/orders/wholesale_retail/widgets/retail_sales_details_page.dart';

// class RetailerSalesOrderCard extends ConsumerWidget {
//   final OrderModel order;

//   const RetailerSalesOrderCard({super.key, required this.order});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final textTheme = Theme.of(context).textTheme;
//     final currency = NumberFormat.simpleCurrency(locale: 'en_IN');

//     // Logic to find a display image from the first item in the order
//     // String? firstImageUrl;
//     // Assuming OrderModel -> items -> OrderItemModel
//     // You might need to adjust based on how you nested the product data in the fetch
//     // The provider used: .select('*, order_items(*, retail_products(product_name, image_urls))')
//     if (order.items != null && order.items!.isNotEmpty) {
//       // In Supabase response, this data might be in a map if not fully deserialized,
//       // but assuming OrderItemModel handles it or we access strictly:
//       // For this display, we might just use the Generic Icon to save complexity
//       // unless OrderItemModel has an imageUrl field.
//     }

//     return Card(
//       margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
//       child: ListTile(
//         isThreeLine: true,
//         // 1. Leading: Visual distinction for "Sale" vs "Purchase"
//         leading: Container(
//           width: 48,
//           height: 48,
//           decoration: BoxDecoration(
//             color:
//                 Colors.orange.shade100, // Different color to distinguish Sales
//             borderRadius: BorderRadius.circular(8),
//           ),
//           child: Icon(Icons.shopping_bag, color: Colors.orange.shade800),
//         ),

//         // 2. Title: Customer Name (or ID if name unavailable)
//         title: Text(
//           "Order #${order.id.substring(0, 8).toUpperCase()}",
//           style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
//         ),

//         // 3. Subtitle: Items count and Date
//         subtitle: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               "${order.items?.length ?? 0} items • ${currency.format(order.totalAmount)}",
//             ),
//             Text(DateFormat.yMd().add_jm().format(order.createdAt)),
//           ],
//         ),

//         // 4. Trailing: Status Chip
//         trailing: SizedBox(
//           width: 110, // Slightly wider for status text
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               StatusChip(status: order.status),
//             ],
//           ),
//         ),

//         onTap: () {
//           // Navigate to Detail Page
//           Navigator.of(context).push(
//             MaterialPageRoute(
//               builder: (context) => RetailerSalesOrderDetailPage(order: order),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

// class StatusChip extends StatelessWidget {
//   final OrderStatus status;
//   const StatusChip({required this.status});

//   @override
//   Widget build(BuildContext context) {
//     Color color;
//     switch (status) {
//       case OrderStatus.pending:
//         color = Colors.orange;
//         break;
//       case OrderStatus.accepted:
//         color = Colors.blue;
//         break;
//       case OrderStatus.shipped:
//         color = Colors.purple;
//         break;
//       case OrderStatus.delivered:
//         color = Colors.green;
//         break;
//       case OrderStatus.cancelled:
//         color = Colors.red;
//         break;
//     }

//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//       decoration: BoxDecoration(
//         color: color.withOpacity(0.1),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: color.withOpacity(0.5)),
//       ),
//       child: Text(
//         status.name.toUpperCase(),
//         style: TextStyle(
//           color: color,
//           fontSize: 10,
//           fontWeight: FontWeight.bold,
//         ),
//         textAlign: TextAlign.center,
//       ),
//     );
//   }
// }
// // --- Make sure to add these imports ---
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:locally/common/models/products/wholesale_product_model.dart';
// import 'package:locally/common/providers/product_service_providers.dart';
// // Import OrderDetailPage (path from example)

// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:locally/common/models/orders/order_model.dart';
// import 'package:locally/common/extensions/content_extensions.dart';
// import 'package:locally/common/widgets/order/order_details.dart';

// // ✅ 1. Converted to a ConsumerWidget
// class RetailOrderCard extends ConsumerWidget {
//   final WholesaleRetailOrder order;
//   // ✅ 2. Added onUpdateStatus parameter
//   final Function(String newStatus) onUpdateStatus;

//   const RetailOrderCard({
//     super.key,
//     required this.order,
//     required this.onUpdateStatus,
//   });

//   @override
//   // ✅ 3. Added WidgetRef ref
//   Widget build(BuildContext context, WidgetRef ref) {
//     final textTheme = Theme.of(context).textTheme;

//     // 4. Get the productId from the first item
//     final String? productId = (order.items.isNotEmpty)
//         // ⚠️ ASSUMPTION: The key is 'productId'.
//         // If your key is 'product_id', change this line.
//         ? order.items.first['productId'] as String?
//         : null;

//     // 5. If no ID, build with fallback data immediately
//     if (productId == null) {
//       return _buildCard(
//         context,
//         ref,
//         textTheme: textTheme,
//         title: 'Order ID: ${order.orderId}',
//         leading: Icon(
//           Icons.receipt_long,
//           color: context.colors.primary,
//           size: 40,
//         ),
//       );
//     }

//     // 6. If ID exists, watch the provider
//     // (Using wholesale provider as the item is a wholesale item)
//     final AsyncValue<WholesaleProduct?> productAsync = ref.watch(
//       wholesaleProductByIdProvider(productId),
//     );

//     // 7. Use .when to build the card based on the state
//     return productAsync.when(
//       data: (product) {
//         // Use product name or fallback to Order ID
//         // ✅ Corrected to use 'name' which is likely in your model
//         final String title =
//             product?.productName ?? 'Order ID: ${order.orderId}';
//         // Get first image URL or null
//         final String? imageUrl =
//             (product != null && product.imageUrls.isNotEmpty)
//             ? product.imageUrls.first
//             : null;

//         return _buildCard(
//           context,
//           ref,
//           textTheme: textTheme,
//           title: title,
//           leading: _buildLeadingImage(context, imageUrl),
//         );
//       },
//       loading: () {
//         // Show a loading state in the card
//         return _buildCard(
//           context,
//           ref,
//           textTheme: textTheme,
//           title: 'Loading product...',
//           leading: Container(
//             width: 48,
//             height: 48,
//             padding: const EdgeInsets.all(12.0),
//             child: const CircularProgressIndicator.adaptive(strokeWidth: 2),
//           ),
//         );
//       },
//       error: (err, stack) {
//         // Show an error state in the card
//         return _buildCard(
//           context,
//           ref,
//           textTheme: textTheme,
//           title: 'Error loading product',
//           leading: Icon(
//             Icons.receipt_long,
//             color: context.colors.error, // Use error color
//             size: 40,
//           ),
//         );
//       },
//     );
//   }

//   /// Helper to build the main Card structure
//   Widget _buildCard(
//     BuildContext context,
//     WidgetRef ref, {
//     required TextTheme textTheme,
//     required String title,
//     required Widget leading,
//   }) {
//     return Card(
//       margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
//       child: ListTile(
//         isThreeLine: true,
//         leading: leading,
//         // ✅ TITLE: Shows Product Name (or fallback)
//         title: Text(
//           title,
//           style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
//           maxLines: 1,
//           overflow: TextOverflow.ellipsis,
//         ),
//         // ✅ SUBTITLE: Shows Total and Date
//         subtitle: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('Total: \$${order.totalAmount.toStringAsFixed(2)}'),
//             Text('Date: ${DateFormat.yMd().format(order.createdAt)}'),
//           ],
//         ),
//         // ✅ TRAILING: Updated to include Chip and Update Button
//         // _orderStatuses = [
//         //   'Pending',
//         //   'Confirmed',
//         //   'Shipped',
//         //   'Delivered',
//         //   'Received',
//         // ];
//         trailing: SizedBox(
//           width: 120,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Chip(
//                 label: Text(order.status),
//                 backgroundColor: order.status == "Received"
//                     ? Colors.green
//                     : order.status == "Delivered"
//                     ? context.colors.primary
//                     : context.colors.surfaceDim,
//                 labelPadding: const EdgeInsets.symmetric(
//                   horizontal: 12,
//                   vertical: 2,
//                 ),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(24), // 👈 Rounded chips
//                   side: BorderSide(color: Colors.transparent),
//                 ),
//                 visualDensity: VisualDensity.compact, // Makes chip smaller
//               ),
//             ],
//           ),
//         ),
//         onTap: () {
//           // ✅ Fixed navigation
//           Navigator.of(context).push(
//             MaterialPageRoute(
//               builder: (context) => OrderDetailPage(
//                 orderId: order.orderId,
//                 isWholesaleSeller: false,
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }

//   /// Helper just for building the leading image, with fallbacks
//   Widget _buildLeadingImage(BuildContext context, String? imageUrl) {
//     // Fallback to icon if no image URL
//     if (imageUrl == null) {
//       return Icon(
//         Icons.receipt_long,
//         color: context.colors.primary,
//         size: 40,
//       );
//     }

//     // Build Image.network if URL exists
//     return ClipRRect(
//       borderRadius: BorderRadius.circular(8.0),
//       child: Image.network(
//         imageUrl,
//         width: 48,
//         height: 48,
//         fit: BoxFit.cover,
//         // Fallback for network error
//         errorBuilder: (context, _, __) => Icon(
//           Icons.receipt_long,
//           color: context.colors.primary,
//           size: 40,
//         ),
//         // Show a loader while image downloads
//         loadingBuilder: (context, child, progress) {
//           if (progress == null) return child;
//           return Container(
//             width: 48,
//             height: 48,
//             padding: const EdgeInsets.all(12.0),
//             child: CircularProgressIndicator.adaptive(strokeWidth: 2),
//           );
//         },
//       ),
//     );
//   }
// }

