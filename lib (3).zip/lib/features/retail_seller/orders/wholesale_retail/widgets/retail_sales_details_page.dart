import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:locally/common/extensions/content_extensions.dart';
import 'package:locally/common/models/orders/consumer_order_model.dart';
import 'package:locally/features/consumer/view_orders/consumer_orders_page.dart';
import 'package:locally/features/retail_seller/orders/wholesale_retail/providers/order_providers.dart';

class RetailerSalesOrderDetailPage extends ConsumerWidget {
  final OrderModel order;

  const RetailerSalesOrderDetailPage({super.key, required this.order});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currencyFormat = NumberFormat.simpleCurrency(locale: 'en_IN');
    final dateFormat = DateFormat('dd MMM yyyy • hh:mm a');

    return Scaffold(
      backgroundColor: context.colors.surface,
      appBar: AppBar(
        title: const Text("Order Details"),
        centerTitle: true,
        backgroundColor: context.colors.surface,
        surfaceTintColor: Colors.transparent,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. Header Card (ID & Date)
            _buildHeaderCard(context, dateFormat),
            const SizedBox(height: 24),

            // 2. Shipping Info
            _SectionLabel(label: "Shipping Details"),
            const SizedBox(height: 8),
            _buildShippingCard(context),
            const SizedBox(height: 24),

            // 3. Items List
            _SectionLabel(label: "Items Ordered"),
            const SizedBox(height: 8),
            _buildItemsList(context, currencyFormat),
            const SizedBox(height: 24),

            // 4. Financials
            _buildFinancialCard(context, currencyFormat),
            const SizedBox(height: 80), // Padding for bottom bar
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomAction(context, ref),
    );
  }

  // ---------------------------------------------------------------------------
  // WIDGETS
  // ---------------------------------------------------------------------------

  Widget _buildHeaderCard(BuildContext context, DateFormat dateFormat) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: context.colors.surfaceContainer,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: context.colors.surface,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.receipt_long, color: context.colors.primary),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Order #${order.id.substring(0, 8).toUpperCase()}",
                  style: context.text.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  dateFormat.format(order.createdAt),
                  style: context.text.bodySmall?.copyWith(
                    color: context.colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          StatusChip(status: order.status), // Using the chip defined in Card
        ],
      ),
    );
  }

  Widget _buildItemsList(BuildContext context, NumberFormat currencyFormat) {
    final items = order.items ?? [];
    if (items.isEmpty) return const SizedBox();

    return Container(
      decoration: BoxDecoration(
        color: context.colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: context.colors.outlineVariant.withOpacity(0.3),
        ),
      ),
      child: Column(
        children: items.map((item) {
          return Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Image Placeholder
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: context.colors.surfaceContainerHigh,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.shopping_bag_outlined,
                    size: 20,
                    color: context.colors.onSurfaceVariant,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.productName ?? "Unknown Product",
                        style: context.text.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        "${item.quantity} units @ ${currencyFormat.format(item.priceAtPurchase)}",
                        style: context.text.bodySmall?.copyWith(
                          color: context.colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  currencyFormat.format(item.quantity * item.priceAtPurchase),
                  style: context.text.bodyMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildFinancialCard(
    BuildContext context,
    NumberFormat currencyFormat,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: context.colors.secondaryContainer.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: context.colors.outlineVariant.withOpacity(0.1),
        ),
      ),
      child: Column(
        children: [
          _summaryRow(
            context,
            "Subtotal",
            currencyFormat.format(order.totalAmount),
          ),
          const SizedBox(height: 16),
          Divider(color: context.colors.outlineVariant.withOpacity(0.2)),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Total",
                style: context.text.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                currencyFormat.format(order.totalAmount),
                style: context.text.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: context.colors.primary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _summaryRow(BuildContext context, String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: context.text.bodyMedium?.copyWith(
            color: context.colors.onSurfaceVariant,
          ),
        ),
        Text(
          value,
          style: context.text.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
      ],
    );
  }

  Widget _buildShippingCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: context.colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: context.colors.outlineVariant.withOpacity(0.3),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.location_on_outlined,
            color: context.colors.onSurfaceVariant,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              order.deliveryAddress,
              style: context.text.bodyMedium?.copyWith(height: 1.3),
            ),
          ),
        ],
      ),
    );
  }

  Widget? _buildBottomAction(BuildContext context, WidgetRef ref) {
    if (order.status == OrderStatus.delivered ||
        order.status == OrderStatus.cancelled) {
      return null;
    }

    final actionText = _getNextActionText(order.status);
    // Logic for button color
    final isError = order.status == OrderStatus.cancelled;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: context.colors.surface,
        boxShadow: [
          BoxShadow(
            blurRadius: 10,
            color: Colors.black.withOpacity(0.05),
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: FilledButton(
          onPressed: () => _advanceStatus(context, ref),
          style: FilledButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 16),
            backgroundColor: isError
                ? context.colors.error
                : context.colors.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            actionText,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }

  String _getNextActionText(OrderStatus status) {
    return switch (status) {
      OrderStatus.pending => "Accept Order",
      OrderStatus.accepted => "Mark as Shipped",
      OrderStatus.shipped => "Mark as Delivered",
      _ => "Close",
    };
  }

  void _advanceStatus(BuildContext context, WidgetRef ref) {
    String? nextStatus;
    switch (order.status) {
      case OrderStatus.pending:
        nextStatus = 'accepted';
        break;
      case OrderStatus.accepted:
        nextStatus = 'shipped';
        break;
      case OrderStatus.shipped:
        nextStatus = 'delivered';
        break;
      default:
        nextStatus = null;
    }

    if (nextStatus != null) {
      ref.read(updateConsumerOrderStatusProvider)(
        orderId: order.id,
        newStatus: nextStatus,
      );
      Navigator.pop(context);
    }
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        label.toUpperCase(),
        style: context.text.labelMedium?.copyWith(
          color: context.colors.onSurfaceVariant,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.0,
        ),
      ),
    );
  }
}
