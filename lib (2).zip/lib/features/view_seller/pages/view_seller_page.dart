// lib/features/view_seller/pages/view_seller_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:locally/common/providers/profile_provider.dart';
import 'package:locally/features/view_seller/widgets/view_seller_body.dart';

class ViewSellerPage extends ConsumerWidget {
  final String sellerId;

  const ViewSellerPage({super.key, required this.sellerId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // This page is only for viewing *other* profiles,
    // so we always use the FutureProvider 'getProfileByIdProvider'.
    final profileAsync = ref.watch(getProfileByIdProvider(sellerId));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Seller Profile'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: profileAsync.when(
        data: (seller) {
          // We found the seller, pass it to the read-only body.
          return ViewSellerBody(seller: seller);
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text(err.toString())),
      ),
    );
  }
}