class WholesaleSellerProfileService {
  Future<void> createProfileOnRegister() await {
    
  }
}
